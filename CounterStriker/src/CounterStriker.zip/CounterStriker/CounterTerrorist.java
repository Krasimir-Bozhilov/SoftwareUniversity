package CounterStriker.repositories;

public class CounterTerrorist extends Player {
    protected CounterTerrorist(String username, int health, int armor, Gun gun) {
        super(username, health, armor, gun);
    }
}
