package CounterStriker.repositories;

public class Terrorist extends Player {
    protected Terrorist(String username, int health, int armor, Gun gun) {
        super(username, health, armor, gun);
    }
}
