package CounterStriker.repositories;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class GunRepository  {
    private ArrayList<CounterStriker.repositories.Gun> models;
    
}
