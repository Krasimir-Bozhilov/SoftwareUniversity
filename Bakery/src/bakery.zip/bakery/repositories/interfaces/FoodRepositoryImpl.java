package bakery.repositories.interfaces;

import java.util.Collection;

public  class FoodRepositoryImpl<T> extends BaseRepository implements FoodRepository {
    @Override
    public T getByName(String name) {
        for (Object model : models) {
            if (model.equals(name)){
                return (T) model;
            }
        }
        return null;
    }

    @Override
    public void add(Object t) {

    }

    @Override
    public Collection<T> getAll() {
        return null;
    }
}
