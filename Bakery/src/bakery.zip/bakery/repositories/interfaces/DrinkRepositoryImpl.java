package bakery.repositories.interfaces;

public class DrinkRepositoryImpl extends BaseRepository implements DrinkRepository {
    @Override
    public Object getByNameAndBrand(String drinkName, String drinkBrand) {
        return null;
    }
}
