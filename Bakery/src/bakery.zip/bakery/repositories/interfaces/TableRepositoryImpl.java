package bakery.repositories.interfaces;

public class TableRepositoryImpl extends BaseRepository implements TableRepository {
    @Override
    public Object getByNumber(int number) {
        for (Object model : models) {
            if (model.equals(number)) {
                return model;
            }
        }
        return null;
    }
}
