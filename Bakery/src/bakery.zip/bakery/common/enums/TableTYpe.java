package bakery.common.enums;

public enum TableTYpe {
    InsideTable,
    OutsideTable
}
